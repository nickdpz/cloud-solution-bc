"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
require("reflect-metadata");
const Config_1 = require("./config/Config");
const Constants_1 = require("./utils/Constants");
const WinstonLogger_1 = require("./utils/logger/winston/WinstonLogger");
let controllerInstance;
const handler = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    const logger = new WinstonLogger_1.WinstonLogger();
    logger.debug("Evento Recibido: %o \n Contexto de Ejecución: %o", event, context);
    try {
        controllerInstance = controllerInstance !== null && controllerInstance !== void 0 ? controllerInstance : Config_1.AppContainer.get(Constants_1.TYPES.MainController);
        return yield controllerInstance.handleEvent(event);
    }
    catch (error) {
        throw error;
    }
});
exports.handler = handler;
