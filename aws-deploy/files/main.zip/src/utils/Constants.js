"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TYPES = exports.CONSTANTS = exports.HTTP_CODES = void 0;
exports.HTTP_CODES = {
    OK: 200,
};
exports.CONSTANTS = {
    LOG_LEVEL: "debug",
    TIMEZONE: "America/Bogota",
};
exports.TYPES = {
    MainPresenter: Symbol.for("MainPresenter"),
    MainService: Symbol.for("MainService"),
    MainController: Symbol.for("MainController"),
    Logger: Symbol.for("Logger"),
};
